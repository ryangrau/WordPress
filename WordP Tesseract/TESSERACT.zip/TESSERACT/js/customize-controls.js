jQuery(document).ready(function($) {											

	$("#accordion-panel-tesseract_social > ul > li > h3:contains('Social Account')").css('color', '#999');
	
} )